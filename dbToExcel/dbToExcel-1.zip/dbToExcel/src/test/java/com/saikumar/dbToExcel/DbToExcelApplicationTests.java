package com.saikumar.dbToExcel;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DbToExcelApplicationTests {

	@Test
	void contextLoads() {
	}

}
