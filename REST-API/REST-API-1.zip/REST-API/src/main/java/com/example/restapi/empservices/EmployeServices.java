package com.example.restapi.empservices;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.restapi.entity.Employe;
import com.example.restapi.repo.EmployeRepository;

@Service
public class EmployeServices {
	
	@Autowired
	private EmployeRepository employeRepo;
	
	public List<Employe> listAll() {
        return employeRepo.findAll();
    }
     
    public void saveEmploye(Employe employe) {
    	employeRepo.save(employe);
    }
     
    public Employe getEmpById(Integer empId) {
        return employeRepo.findById(empId).get();
    }
     
    public void deleteEmpById(Integer empId) {
    	employeRepo.deleteById(empId);
    }

}
